<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Customer;

class customerController extends Controller
{
    public function index()
    {
        return view('customer');
    }
    public function store()
    {
        print_r($request->all());
        $customer =new customer;
        $customer->name=$request['name'];
        $customer->email=$request['email'];
        $customer->password=$request['password'];
        $customer->country=$request['country'];
        $customer->state=$request['state'];
        $customer->gender=$request['gender'];
    }
}
