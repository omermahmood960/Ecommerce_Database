        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="" class="form-label"><?php echo e($label); ?></label>
                <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>"  id="user_name" class="form-control">
                <span class="text-danger">
                 <!--  -->
                </span>
        </div><?php /**PATH D:\xampp-7-4-33\htdocs\firstProject\resources\views/components/input.blade.php ENDPATH**/ ?>