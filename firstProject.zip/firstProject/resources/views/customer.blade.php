<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container-fluid my-5">
    <div class="row my-5"></div>
        <h1 class=" text-center my-5">Customer Registration</h1>
     <form action="" method="post" enctype="multipart/form-data">
                              <!--------Name------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="user_name" class="form-label">Name</label>
                <input type="text" name="user_name" value="" id="user_name" class="form-control" placeholder="Enter Name">
        </div>
                              <!--------User Email------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="user_email" class="form-label">Email</label>
                <input type="text" name="user_email" value="" id="user_email" class="form-control" placeholder="Enter Email">
        </div>
                            <!--------User Password------->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_password" class="form-label">Password</label>
             <input type="password" name="user_password" id="user_password" class="form-control" value="" placeholder="Enter Password" required>
        </div>
        
                           <!--------------Address------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_password" class="form-label">Address</label>
             <input type="text" name="user_address" id="user_address" class="form-control" value="" placeholder="Enter Address" required>
        </div>
                            <!-------------Mobile Number---->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_phone" class="form-label">Mobile Number</label>
             <input type="text" name="user_phone" id="user_phone" class="form-control" value="" placeholder="Enter Phone Number" required>
        </div>
                            <!-------------Country---->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_phone" class="form-label">Country</label>
             <input type="text" name="user_phone" id="user_phone" class="form-control" value="" placeholder="Enter Phone Number" required>
        </div>

        <div class="form-outline mb-4 w-50 m-auto my-4">
                <button type="submit" class="bg-success p-2 my-3 border-0 text-white" name="update" onclick="return confirm('Are you sure to update?')">Update</button>
        </div>
     </form>
    </div>
         
     </form>
    </div>
</body>
</html>