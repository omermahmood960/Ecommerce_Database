        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="" class="form-label">{{$label}}</label>
                <input type="{{$type}}" name="{{$name}}"  id="user_name" class="form-control">
                <span class="text-danger">
                 <!-- {{-----   @error('name')
                    {{$message}}
                    @enderror ----}} -->
                </span>
        </div>