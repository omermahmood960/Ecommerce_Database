<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name="mystore";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$db_name);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
else
// echo '<script>alert("Database Connection Successfull")</script>';
?>