<?php
include('../databases/connection.php');
function getProducts()
{
    $select_query="Select * from `products` order by rand() LIMIT 0,9";
    $result_query=mysqli_query($conn,$select_query);

    while($row=mysqli_fetch_assoc($result_query))
    {
        $product_id=$_POST['product_id'];
        $product_title=$_POST['product_title'];
        $product_descp=$_POST['product_description'];
        $product_keywords=$_POST['product_keywords'];
        $product_category=$_POST['product_category'];
        $product_brand=$_POST['product_brand'];
        $product_price=$_POST['product_price'];
        echo "<div class='col-md-6 col-lg-4 m-auto mb-3'>
        
        "
    }
}

?>