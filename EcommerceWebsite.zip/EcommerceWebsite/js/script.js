//----------------Special CountDown Timer------------------//
let dayItem=document.querySelector("#days");
let hoursItem=document.querySelector("#hours");
let minutesItem=document.querySelector("#min");
let secondsItem=document.querySelector("#sec");

let countDown=()=>
{
    let futureDate=new Date("25 June 2023");
    let currentDate=new Date();
    let myDate=futureDate-currentDate;

    let days=Math.floor(myDate /1000 / 60 / 24);
    let hours=Math.floor(myDate /1000 / 60 / 60 ) % 24 ;
    let minutes=Math.floor(myDate /1000 / 60) % 60 ;
    let seconds=Math.floor(myDate /1000) % 60 ;

    dayItem.innerHTML=days;
    hoursItem.innerHTML=hours;
    minutesItem.innerHTML=minutes;
    secondsItem.innerHTML=seconds;
}
countDown();

setInterval(countDown,1000)
//-----------------------JS for Toggle Form----------------//
var loginForm=document.getElementById("#LoginForm");
var regForm=document.getElementById("#RegForm");
var indicator=document.getElementById("#indicator");

          //------login function-------//
function register()
{
    regForm.style.transform="translateX(0px)";
    loginForm.style.transform="translateX(0px)";
    indicator.style.transform="translateX(100px)";
}
function login()
{
    regForm.style.transform="translateX(300px)";
    loginForm.style.transform="translateX(300px)";
    indicator.style.transform="translateX(100px)";
}
