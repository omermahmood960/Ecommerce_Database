<?php
include('../databases/connection.php');
if(isset($_POST['insert_brands']))
{
   $brand_title=$_POST['brand_title'];
   //Select data from the database
   $select_query="Select * from `brands` where brand_title='$brand_title'";
   $result_select=mysqli_query($conn,$select_query);
   $number=mysqli_num_rows($result_select);
   
   if($number>0)
   {
      echo '<script>alert("This Brand is already present in database")</script>';
   }
   else
   {
      $insert_query="insert into `brands`(brand_title) values ('$brand_title')";
      $result=mysqli_query($conn,$insert_query);
            if($result)
            {
                echo '<script>alert("Brand has been inserted successfully")</script>';
            }
   }
}
?>           
<div class="container align-items-center my-4">
<form class="form-horizontal" action="" method="post">
  <div class="form-group">
    <label class="control-label col-sm-2 text-danger" for="brands">Brands</label>
    <div class="col-sm-10 mb-4">
      <input type="text" class="form-control" id="brands" name="brand_title" placeholder="Enter Brands">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="bg-info p-2 my-3 border-0 text-white" name="insert_brands">Insert Brands</button>
    </div>
  </div>
</form>
</div>