<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsiveness.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <!--------Navbar------------>
    <div class="container-fluid">
               <!---------First Child------>
        <nav class="navbar navbar-expand-lg navbar-light bg-info">
            <div class="container-fluid">
                <img src=".././images/logo.png" class="img-fluid">
                <nav class="navbar navbar-expand-lg">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a href="#">Welcome Guest</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
               <!---------Details---->
                 <div class="container text-center my-4">
                     <h2>Manage Details</h2>
                 </div>
                 <!-----Admin Options-------->
                 <div class="row">
                    <div class="col-md-12 p-1">
                        <div class="admin-roles text-center p-4 col-sm-12">
                            <button class="border-0 mx-4 "><a href="products/insert_products.php" class="nav-link text-light bg-info my-1 p-4 hover-overlay">Insert Products</a> </button>
                            <button class="border-0 mx-4"><a href="admin.php?view_products" class="nav-link text-light bg-info my-1 p-4">View Products</a></button>
                            <button class="border-0 mx-4"><a href="admin.php?insert_category" class="nav-link text-light bg-info my-1 p-4">Insert Categories</a></button>
                            <button class="border-0 mx-4"><a href="#" class="nav-link text-light bg-info my-1 p-4">View Categories</a></button>
                            <button class="border-0"><a href="admin.php?insert_brand" class="nav-link text-light bg-info my-1 p-4">Insert Brands</a></button>
                            <button class="border-0 mx-4"><a href="#" class="nav-link text-light bg-info my-1 p-4">All Orders</a></button>
                            <button class="border-0 mx-4"><a href="#" class="nav-link text-light bg-info my-1 p-4">All Payments</a></button>
                            <button class="border-0 mx-4"><a href="#" class="nav-link text-light bg-info my-1 p-4">List Users</a></button>
                            <button class="border-0 mx-4"><a href="#" class="nav-link text-light bg-info my-1 p-4">Log Out</a></button>
                        </div>
                    </div>
                 </div>
                 <!--------Fourth Child---------->
                 <div class="container">
                    <?php
                          if(isset($_GET['insert_category']))
                          {
                            include('categories/insert_categories.php');
                          }
                          if(isset($_GET['insert_brand']))
                          {
                            include('brands/insert_brands.php');
                          }
                          if(isset($_GET['view_products']))
                          {
                            include('products/view_products.php');
                          }

                          
                    ?>
                 </div>
    </div>

    <!--------Footer Section---->
    <footer>
        <div class="container-fluid text-white bg-danger position-absolute bottom-0">
          <div class="row align-items-center">
            <div class="col-12 col-lg-6 p-1 p-lg-3 text-center text-lg-start">
              <p class="my-0">CopyRight @ 2023 <a href="#">E-Shop</a>  All Rights Reserved</p>
            </div>
            <div class="col-12 col-lg-6 p-1 p-lg-3 text-center text-lg-end">
              <p>Designed by <a href="#" target="_blank">CODE4Education</a>.</p>
            </div>
          </div>
        </div>
      </footer>
    
</body>
</html>