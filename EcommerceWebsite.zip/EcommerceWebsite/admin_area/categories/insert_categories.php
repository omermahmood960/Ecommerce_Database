<?php
include('../databases/connection.php');
if(isset($_POST['insert_category']))
{
   $category_title=$_POST['category_title'];
   //Select data from the database
   $select_query="Select * from `categories` where category_title='$category_title'";
   $result_select=mysqli_query($conn,$select_query);
   $number=mysqli_num_rows($result_select);
   
   if($number>0)
   {
      echo '<script>alert("Category is already present in database")</script>';
   }
   else
   {
      $insert_query="insert into `categories`(category_title) values ('$category_title')";
      $result=mysqli_query($conn,$insert_query);
   
  
   if($result)
   {
      echo '<script>alert("Category has been inserted successfully")</script>';
   }
}
}
?>
       <!-----------------Categories Form--------------->          
<div class="container align-items-center my-4">
<form class="form-horizontal" action="" method="post">
  <div class="form-group">
    <label class="control-label col-sm-2 text-danger" for="email">Categories</label>
    <div class="col-sm-10 mb-4">
      <input type="text" class="form-control" id="categories" name="category_title" placeholder="Enter Category">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="bg-info p-2 my-3 border-0 text-white" name="insert_category">Insert Categories</button>
    </div>
  </div>
</form>
</div>


