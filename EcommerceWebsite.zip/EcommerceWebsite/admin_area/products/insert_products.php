<?php
include('../../databases/connection.php');
if(isset($_POST['insert_product']))
{
    // Condition for Already Present product in the database
    $prod_title=$_POST['product_title'];
    $prod_descp=$_POST['product_description'];
    $prod_keywords=$_POST['product_keywords'];
    $prod_category=$_POST['product_category'];
    $prod_brand=$_POST['product_brand'];
    $prod_price=$_POST['product_price'];
    $prod_quantity=$_POST['product_quantity'];

    //Accessing the images file and name
    $prod_image=$_FILES['product_image']['name'];
    //Accessing the temporary name
    $temp_image=$_FILES['product_image']['tmp_name'];
    
       
        move_uploaded_file($temp_image,"../product_images/$prod_image");
        
        //Insert the data into database table
        $insert_product="insert into `products` (product_title,product_description,product_keywords,product_category,product_brand,product_image,price,total_quantity) Values ('$prod_title','$prod_descp','$prod_keywords','$prod_category','$prod_brand','$prod_image','$prod_price','$prod_quantity')";
        $result=mysqli_query($conn,$insert_product);

        if($result)
        {
        echo '<script>alert("Product has been inserted successfully")</script>';
        }
        else
        {
            echo '<script>alert("Something is wrong")</script>';
        }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard Insert-Products </title>
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="../../css/responsiveness.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container  my-4">
        <h2 class="text-center">Insert Products</h2>
        <!--------------Products Form------------->
        <form action="" method="post" enctype="multipart/form-data">
                        <!--------title--->
            <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="product_title" class="form-label">Product_Title</label>
                <input type="text" name="product_title" id="product_title" class="form-control" placeholder="Enter Product Title" required>
            </div>
                         <!----description-->
            <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="product_description" class="form-label">Product_Description</label>
                <input type="text" name="product_description" id="product_description" class="form-control" autocomplete="off" placeholder="Enter Product Description" required>
            </div>
                          <!----keywords----->
            <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="product_keywords" class="form-label">Product Keywords</label>
                <input type="text" name="product_keywords" id="product_keywords" class="form-control" autocomplete="off" placeholder="Enter product keywords" required>
            </div>
                         <!---------Categories------------>
            <div class="form-outline mb-4 w-50 m-auto my-4">
                <select name="product_category" id="product_categories" class="form-select">
                    <option value="">Select a Category</option>
                    <?php
                    $select_query="select * from categories";
                    $result_query=mysqli_query($conn,$select_query);
                    while($row=mysqli_fetch_assoc($result_query))
                    {
                        $category_title=$row['category_title'];
                        $category_id=$row['category_id'];
                        echo "<option value='$category_id'>$category_title</option>";
                    }
                    ?>
                </select>
            </div>
                         <!-----------Brands--------------->
            <div class="form-outline mb-4 w-50 m-auto my-4">
             <select name="product_brand" id="product_brand" class="form-select">
                <option value="">Select a Brand</option>
                <?php
                    $select_query="select * from brands";
                    $result_query=mysqli_query($conn,$select_query);
                    while($row=mysqli_fetch_assoc($result_query))
                    {
                        $brand_title=$row['brand_title'];
                        $brand_id=$row['brand_id'];
                        echo "<option value='$brand_id'>$brand_title</option>";
                    }
                    ?>
            </select>
            </div>
                          <!--------Image----->
            <div class="form-outline mb-4 w-50 m-auto ">
                <label for="product_image" class="form-label">Product Image</label>
                <input type="file" name="product_image" id="product_image" class="form-control" autocomplete="off" required>
            </div>
                           <!-------Price-------->
            <div class="form-outline mb-4 w-50 m-auto ">
                <label for="product_image" class="form-label">Price:</label>
                <input type="text" name="product_price" id="product_price" class="form-control" placeholder="Enter the Product Price" autocomplete="off" required>
            </div>
                          <!--------Quantity-------->
            <div class="form-outline mb-4 w-50 m-auto ">
                <label for="product_image" class="form-label">Quantity</label>
                <input type="text" name="product_quantity" id="product_quantity" class="form-control" placeholder="Enter the Product Quantity" autocomplete="off" required>
            </div>
                           <!-------Submit------>
            <div class="form-outline mb-4 w-50 m-auto ">
               <button type="submit" name="insert_product" class="bg-info p-2 my-3 border-0 text-white">Insert Product</button>
            </div>
        </form>
    </div>
</body>
</html>
