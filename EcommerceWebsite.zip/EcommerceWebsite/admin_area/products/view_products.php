<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      <?php
           include('../databases/connection.php');
       ?>
<div class="container text-center">
    
    <h3 class="text-info my-5">All Products</h3>
    <table class="table table-bordered mt-5">
        <thead>
        <tr>
            <th>SI No</th>
            <th>Product Title</th>
            <th>Product Category</th>
            <th>Product Brand</th>
            <th>Product Price</th>
            <th>Total Quantity</th>
        </tr>
        </thead>

        <tbody class="bg-info text-light">
        <?php
            $get_products="select * from products'";
            $result_products=mysqli_query($conn,$get_products);
            $number=1;
            while($row_products=mysqli_fetch_assoc($result_products))
            {
               $product_title=$row_products['product_title'];
               $product_category=$row_products['product_category'];
               $product_brand=$row_products['product_brand'];
               $product_price=$row_products['price'];
               $product_qty=$row_products['total_quantity'];

               echo "<tr>
                      <td>$number</td>
                      <td>$product_title</td>
                      <td>$product_category</td>
                      <td>$product_brande</td>
                      <td>$product_price</td>
                      <td>$product_qty</td>
                     </tr> ";
                    $number++;

            }

    ?>
        </tbody>
        
     </table>
</div>
</body>
</html>