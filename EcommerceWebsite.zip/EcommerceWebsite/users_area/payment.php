<?php
include('../databases/connection.php');
session_start();
$user_id=$_SESSION['id'];
$total_bill=$_SESSION['bill'];
//Select the cart Items
$select_cart_items="select * from add_to_cart where user_id='$user_id'";
$result_cart_items=mysqli_query($conn,$select_cart_items);
$count_items=mysqli_num_rows($result_cart_items);

//Generate Transaction Id 
$transaction="insert into transaction (total_cart_items,total_bill,user_id) values ('$count_items','$total_bill','$user_id')";
$result_transaction=mysqli_query($conn,$transaction);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <?php
         include('forms/bootstrap_classes.php');
         include('header.php');
    ?>
</head>
<body>
    <div class="conatiner my-5">
        <h2 class="text-center text-info my-5">Payment Options</h2>
        <div class="row">
            <div class="col-md-6">
                <a href="confirm_payment.php" onclick="return confirm('Are you sure to Confirm?')"> <h2 class="text-center">Payment Mode</h2></a>
            </div>
        </div>
    </div>
    
</body>
</html>