<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Site</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsiveness.css">
    <?php
        include('header.php');
    ?>

</head>
<body>
<section id="products" class="products">
            <!--------Products Images--------->
        <div class="container text-center my-4">
          <h1 class="my-4">OUR PRODUCTS</h1>
            <!------First Card Row------------->

                  <!---------Dairy Products--------->
          <div class="row g-3">
                     <!-------Fetching Products from the database--->
            <?php
                  include('../databases/connection.php');
                  $select_query="select * from `products`";
                  $result_query=mysqli_query($conn,$select_query);
                  while($row=mysqli_fetch_assoc($result_query))
                  {
                    $product_id=$row['product_id'];
                    $product_title=$row['product_title'];
                    $product_descp=$row['product_description'];
                    $product_keywords=$row['product_keywords'];
                    $product_category=$row['product_category'];
                    $product_brand=$row['product_brand'];
                    $product_image=$row['product_image'];
                    $product_price=$row['price'];
                    echo "<div class='col-12 col-md-6 col-lg-4'>
                          <div class='card'>
                         <img src='../admin_area/product_images/$product_image' class='img-fluid card-img-top'>
                         <div class='card-body text-center'>
                         <h4 class='card-title'>$product_title</h4>
                         <p>$product_descp</p>
                          <p>RS:  $product_price</p>
                          <button type='submit' class='btn btn-danger'>Add To Cart</button>
                          </div>
                          </div>
                          </div>";
                  }
              ?>  
            </div>
          </div>

        </div>    
</section>
    
</body>
</html>
