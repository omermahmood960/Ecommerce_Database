<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Site</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsiveness.css">
    <?php
        include('header.php');
        include_once('../databases/connection.php');
    ?>

</head>
<body>
     <?php
     session_start();
     $user_id=$_SESSION['id'];
     //select data of User logged in from the database table
     $select_query="select * from users_table where user_id='$user_id'";
     $result_query=mysqli_query($conn,$select_query);
     $row=mysqli_fetch_assoc($result_query);

     //fetching the data from database and store into mysql
     $user_name=$row['user_Name'];
     $user_email=$row['user_email'];
     $user_pass=$row['user_password'];
     $user_address=$row['user_address'];
     $user_numb=$row['user_MobileNo'];
     ?>
<section id="edit-form" class="edit-form">
<div class="container-fluid my-5">
    <div class="row my-5"></div>
        <h1 class=" text-center my-5">General Account Settings</h1>
     <form action="forms/insert.php" method="post" enctype="multipart/form-data">
                              <!--------Name------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="user_name" class="form-label">Name</label>
                <input type="text" name="user_name" value="<?php echo $user_name ?>" id="user_name" class="form-control">
        </div>
                              <!--------User Email------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="user_email" class="form-label">Email</label>
                <input type="text" name="user_email" value="<?php echo $user_email ?>" id="user_email" class="form-control" disabled>
        </div>
                            <!--------User Password------->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_password" class="form-label">Password</label>
             <input type="password" name="user_password" id="user_password" class="form-control" value="<?php echo $user_pass ?>" placeholder="Enter Password" required>
        </div>
        
                           <!--------------Address------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_password" class="form-label">Address</label>
             <input type="text" name="user_address" id="user_address" class="form-control" value="<?php echo $user_address ?>" placeholder="Enter Address" required>
        </div>
                            <!-------------Mobile Number---->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_phone" class="form-label">Mobile Number</label>
             <input type="text" name="user_phone" id="user_phone" class="form-control" value="<?php echo $user_numb ?>" placeholder="Enter Phone Number" required>
        </div>

        <div class="form-outline mb-4 w-50 m-auto my-4">
             <button type="submit" class="bg-success p-2 my-3 border-0 text-white" name="update" onclick="return confirm('Are you sure to update?')">Update</button>
             <button type="submit" class="bg-info p-2 my-3 mx-4 border-0 text-white" name="cancel">Cancel</button>
        </div>
     </form>
    </div>
          
</section>
    
</body>
</html>
