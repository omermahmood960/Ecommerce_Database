<?php
include('../databases/connection.php');
include('forms/bootstrap_classes.php');
session_start();
$user_id=$_SESSION['id'];

if(isset($_POST['confirm_pay']))
{
       //select the transaction ID from transaction table
    $transaction_data="select * from transaction where user_id='$user_id'";
    $result_transaction=mysqli_query($conn,$transaction_data);
    $rows_transaction=mysqli_fetch_assoc($result_transaction);
    $transaction_id=$rows_transaction['transaction_id'];
    //Select the cart Items
    $select_cart_items="select * from add_to_cart where user_id='$user_id'";
    $result_cart_items=mysqli_query($conn,$select_cart_items);
    //Avoid inserting the duplicate orders into the table
    $select_order_data="select * from order_details where transaction_id='$transaction_id'";
    $result_order_data=mysqli_query($conn, $select_order_data);
    $count_data=mysqli_num_rows($result_order_data);
    $insert_order="insert into order (transaction_id) values('$transaction_id')";
    $result_insert_order=mysqli_query($conn,$insert_order);
    if($count_data==0)
{
     while($rows_cartItems=mysqli_fetch_assoc($result_cart_items))
    {
        $product_id=$rows_cartItems['product_id'];
        $product_qty=$rows_cartItems['product_quantity'];
       
        //Selecting the product price
        $select_product_data="select * from products where product_id='$product_id'";
        $result_product_data=mysqli_query($conn,$select_product_data);
        $rows_product=mysqli_fetch_assoc($result_product_data);
        $product_price=$rows_product['price'];
        $product_title=$rows_product['product_title'];
        //insert the order details
        
        $insert_order="insert into order_details (transaction_id,product_title,ordered_qty,product_price) values ('$transaction_id','$product_title','$product_qty','$product_price')";
        $result_order=mysqli_query($conn,$insert_order);
    }
    //----Product Inventory Stock-------------//
    while($row_price=mysqli_fetch_array($result_cart_items))
{
   $product_id=$row_price['product_id'];
   $ordered_qty=$row_price['product_quantity'];
   $select_product="select * from `products` where product_id='$product_id'";
   $run_price=mysqli_query($conn,$select_product);
   while($row_products=mysqli_fetch_array($run_price))
   {
        $product_price=$row_products['price'];
        $product_total_qty=$row_products['total_quantity'];
        $product_available_qty=$product_total_qty-$ordered_qty;
        $subtotal=$ordered_qty*$product_price;
            //insertion into product Inventory
        $insert_product_inventory="insert into product_inventory_mgm (product_id,product_qty_available,user_id,purchased_qty,transaction_date) values ('$product_id','$product_available_qty',' $user_id','$ordered_qty',NOW())";
        $result_product_inventory=mysqli_query($conn,$insert_product_inventory);

   }   
}
}
else 
{
    echo '<div class="alert alert-primary" role="alert">
           That transaction order has already done
          </div>';
}
   // Delete from the cart items
            $delete_cart_items="delete from add_to_cart where user_id='$user_id'";
            $result_delete_cart_items=mysqli_query($conn,$delete_cart_items);
    

    //----------------------//
    $transaction_id=$_POST['transaction_id'];
    $total_amount=$_POST['total_bill'];
    $payment_mode=$_POST['payment_mode'];  
}
?>