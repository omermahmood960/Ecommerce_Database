<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <h1 class=" text-center my-4">Login Form</h1>
        <form action="" method="post" enctype="multipart/form-data">
                              <!--------User Email------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
            <label for="user_email" class="form-label">Email</label>
            <input type="text" name="user_email" id="user_email" class="form-control" placeholder="Enter Valid Email ID" required>
        </div>
                            <!--------User Password------->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_password" class="form-label">Password</label>
             <input type="text" name="user_password" id="user_password" class="form-control" placeholder="Enter Password" required>
        </div>

        <div class="form-outline mb-4 w-50 m-auto my-4 ">
             <button type="submit" class="bg-success p-3 my-3 border-0 text-white">Login</button>
        </div>
        

        </form>
    </div>
</body>
</html>