<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Cart</title>
</head>
<body>
    <?php
        include('header.php');
    ?>
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12 my-5">
                <h1 class="text-info my-5">My Cart</h1>
            </div>
        </div>
    </div>
    <!-------------Table for Cart Data--------------->
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-9 col-sm-12 col-md-8">
                <table class="table table-bordered text-center">
                        <!---Heading Row--->
                    <thead class="bg-danger text-white">
                        <th>Index No</th>
                        <th>Product title</th>
                        <th>Product Price</th>
                        <th>Product Quantity</th>
                        <th>Total Price</th>
                        <th>Update</th>
                        <th>Delete</th>
                    </thead>
                        <!----Fetching the data from the Database--->
                    <tbody>
                        <?php
                              //Include database Connection
                              include('../databases/connection.php');
                               $totalp=0;
                               $total_bill=0;
                               if(isset($_SESSION['user']))
                               {
                                $user_id=$_SESSION['id'];
                               }
                        //       if(isset($_SESSION['cart']))
                            //   {
                                //Select data from the database and display it on the browser
                                $select_cart_data="select * from add_to_cart where user_id=$user_id";
                                $result_cart_data=mysqli_query($conn,$select_cart_data);
                                //testing product table columns
                                $number=0;
                                $total_bill=0;
                                while($rows_addToCart=mysqli_fetch_assoc($result_cart_data))
                                {
                                    $product_id=$rows_addToCart['product_id'];
                                    $product_quantity=$rows_addToCart['product_quantity'];
                                    $select_product_details="select * from products where product_id='$product_id'";
                                    $result_product_details=mysqli_query($conn,$select_product_details);
                                      while($rows_product_details=mysqli_fetch_assoc($result_product_details))
                                      {
                                        $product_price=$rows_product_details['price'];
                                        $product_title=$rows_product_details['product_title'];
                                        $total_price=$product_price*$product_quantity;
                                        $total_bill+=$total_price;
                                        echo " <form action='add_to_cart.php' method='POST'>
                                                <tr>
                                                    <td>$number</td>
                                                    <input type='hidden' name='product_id' value='$product_id'>
                                                    <input type='hidden' name='product_title' value='$product_title'>
                                                    <input type='hidden' name='product_price' value='$product_price'>
                                                    <td>$product_title</td>
                                                    <td>$product_price</td>
                                                    <td><input type='number' name='product_quantity' value='$product_quantity'></td>
                                                    <td>$total_price</td>
                                                    <td><button class='btn btn-warning' name='update'>Update</button></td>
                                                    <td><button class='btn btn-danger' name='delete'>Delete</button></td>
                                                    <input type='hidden' name='item' value='$product_title'>
                                                    
                                                </tr> 
                                                </form>";
                                                    $number++;

                                      } 
                                    
                                }
                                $_SESSION['bill']=$total_bill;
                                
                              // }
                        ?>
                    </tbody>
                    
                </table>
            </div>
        </div>
        <div class="container text-center">
            <div class="row">
                <div class="col-lg-9 col-md-6">
                    <h1>Total Bill </h2>
                    <h2 class="text-info"> <?php   echo '<br> RS:'.$total_bill   ?></h2>
                </div>
            <div class="col-lg-9 col-md-6">
                <button class="border-0 mx-4"><a href="Payment.php" class="nav-link text-light bg-info my-1 p-4">CheckOut</a></button>
                </div>
            </div>
        </div>
    </div>

    
</body>
</html>