<?php
include('../databases/connection.php');
session_start();
$user_id=$_SESSION['id'];
//getting total items and total price of all items
$total_price=0;
$select_cart_items="select * from add_to_cart where user_id='$user_id'";
$result_cart_items=mysqli_query($conn,$select_cart_items);
//count the cart items and getting their quantity
$count_cart_items=mysqli_num_rows($result_cart_items);
$status="pending";
while($row_price=mysqli_fetch_array($result_cart_items))
{
   $product_id=$row_price['product_id'];
   $ordered_qty=$row_price['product_quantity'];
   $select_product="select * from `products` where product_id='$product_id'";
   $run_price=mysqli_query($conn,$select_product);
   while($row_products=mysqli_fetch_array($run_price))
   {
        $product_price=$row_products['price'];
        $product_total_qty=$row_products['total_quantity'];
        $product_available_qty=$product_total_qty-$ordered_qty;
        $subtotal=$ordered_qty*$product_price;
        //insert_Query
         $sql_query="insert into `user_orders` (product_id,product_ordered_quantity,product_price,total_price,order_status,user_id,order_date) Values('$product_id','$ordered_qty','$product_price','$subtotal','$status','$user_id',NOW())";
       
        $result_query=mysqli_query($conn,$sql_query);
        if($result_query)
        {
            //insertion into product Inventory
        $insert_product_inventory="insert into product_inventory_mgm (product_id,product_qty_available,user_id,purchased_qty,transaction_date) values ('$product_id','$product_available_qty',' $user_id','$ordered_qty',NOW())";
        $result_product_inventory=mysqli_query($conn,$insert_product_inventory);

        }
   }   
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Orders</title>
    <?php
         include('forms/bootstrap_classes.php');
    ?>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
               <h2><a href="user_orders.php" class="nav-link text-primary">My Orders</a></h2> 
            </div>
        </div>
    </div>
</body>
</html> 