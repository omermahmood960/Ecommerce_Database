<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
             <!-- jQuery library -->
     <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

            <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

            <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

            <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
            <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <?php
    session_start();
         $count=0;
        if(isset($_SESSION['cart']))
        {
           $count=count($_SESSION['cart']);
        }
    ?>
     <!----------------Navigation Bar----------------->
     <div class="bg-img">
        <nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
            <div class="container p-2">
                
                <a href="" class="navbar-brand text-warning font-weight-bold">
                    <img src="../images/logo.png" class="img-fluid">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-bs-toggle="collapse" data-target="#collapsenavbar"><span class="navbar-toggler-icon"></span></button>

                <div class="collapse navbar-collapse text-center" id="collapsenavbar">
                  <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a href="index.php" class="nav-link text-primary"><i class="fas fa-home"></i> Home</a></li>
                    <li class="nav-item"><a href="products.php" class="nav-link text-primary">Products</a></li>
                    <li class="nav-item"><a href="user_orders.php" class="nav-link text-primary">My Orders</a></li>
                    <li class="nav-item"><a href="view_cart.php" class="nav-link text-primary"><i class="fa-solid fa-cart-shopping"></i>Cart  <?php
                    // echo $count ?></a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-primary">Hello </i>
                    <?php
                    if(isset($_SESSION['user']))
                    {
                        echo '</li>'.$_SESSION['user'];
                        echo '<div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown"></a>
                                <div class="dropdown-menu">
                                <a href="edit_form.php" class="dropdown-item">Settings</a>
                                <a href="forms/logout.php" class="dropdown-item">Logout</a>
                                </div>
                               </div>';
                                
                    }
                    else
                    {
                       echo '<li class="nav-item"><a href="forms/userLogin.php" class="nav-link text-primary">Login </a></li>' ;
                       echo '<li class="nav-item"><a href="forms/userRegistration.php" class="nav-link text-primary">Registration </a></li>';
                    }
                    ?>
                  </ul>
            </div>    
            </div>
        </nav>     
    </div>
</body>
</html>