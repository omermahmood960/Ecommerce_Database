<?php
//session variable
include('../databases/connection.php');
include('forms/bootstrap_classes.php');
session_start();
    // Check whether usser Logged in or not
    if(isset($_SESSION['user']))
    {
        $user_id=$_SESSION['id'];
        $product_id=$_POST['product_id'];
        $product_quantity=$_POST['product_quantity'];
        $product_name=$_POST['product_title'];
        $product_price=$_POST['product_price'];
         
        if(isset($_POST['add_to_cart']))
     {
        $check_product=array_column($_SESSION['cart'],'productName');
        if(in_array($product_name,$check_product))
        {
            echo "<script>alert('Product already added');
                    window.location.href='index.php';
                    </script>";
        }
            else
        {
                $_SESSION['cart'][]=array('productID'=>$product_id,'userID'=>$user_id,'productName'=>$product_name,'product_price'=> $product_price,'product_quantity'=> $product_quantity);
                //check the availability of the products
                    $select_product_availability="select * from product_inventory_mgm where product_id='$product_id'";
                    $result_product_availability=mysqli_query($conn,$select_product_availability);
                    $rows_product_availability=mysqli_fetch_assoc($result_product_availability);
                    $product_available_qty=$rows_product_availability['product_qty_available'];
                    if($product_quantity<=$product_available_qty)
                    {
                        // insertion into the database
                        $sql_query="insert into `add_to_cart` (product_id,user_id,product_quantity) Values('$product_id','$user_id','$product_quantity')";
                        $result_query=mysqli_query($conn,$sql_query);
                         header("location:view_cart.php");  
                    }
                    else
                    {
                        echo '<div class="alert alert-primary" role="alert">
                            Product Not Available in that quantity
                        </div>'; 
                        echo '<script>window.location.href="index.php"</script>';
                    }      
         
        } 
     }
        
            //remove the products
            if(isset($_POST['delete']))
            {
                foreach($_SESSION['cart'] as $key => $value)
                {
                    if($value['productName']===$_POST['item'])
                    {
                        unset($_SESSION['cart'][$key]);
                        $_SESSION['cart']=array_values($_SESSION['cart']);
                        header('location:view_cart.php');
                    }

                }
                //Deletion from the database table
                $delete_cart_item="delete from add_to_cart where product_id='$product_id'";
                $result_deletion_item=mysqli_query($conn,$delete_cart_item);

                if($result_deletion_item)
                {
                    echo '<script>alert("Item Deleted Successfully")
                    window.location.href="index.php";
                    </script>';
                }
                
            }
        //update the products
        if(isset($_POST['update']))
        {
            foreach($_SESSION['cart'] as $key => $value)
            {
                if($product_name===$_POST['item'])
                {
                    $_SESSION['cart'][$key]=array('productName'=>$product_name,'product_price'=> $product_price,'product_quantity'=> $product_quantity);
                    header("location:view_cart.php");     
                }

            }

        }
    }
    else
    {
        header('location:forms/userLogin.php');
    }

?>