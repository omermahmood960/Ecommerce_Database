<?php
include('../databases/connection.php');
   if(isset($_POST['register']))
   {
    //Fetching the data from registration form
    $user_name=$_POST['user_name'];
    $user_email=$_POST['user_email'];
    $user_pass=$_POST['user_password'];
    $user_conf_pass=$_POST['user_cpassword'];
    $user_address=$_POST['user_address'];
    $user_number=$_POST['user_phone'];
    if($user_pass===$user_conf_pass)
    {
        $hash_pass=password_hash($user_pass,PASSWORD_DEFAULT);
        //select query for unique users
        $select_query="select * from users_table where user_email='$user_email'";
        $result_query=mysqli_query($conn,$select_query);
        $number=mysqli_num_rows( $result_query);
        if($number==0)
        {
            //Insertion into the database
            $sql_query="insert into `users_table` (user_Name,user_email,user_password,user_address,user_mobileNo) Values('$user_name','$user_email','$hash_pass',' $user_address',' $user_number')";
            $result_query=mysqli_query($conn,$sql_query);
            
            if($result_query)
            {
               echo '<script>alert("User is successfully Registered")</script>';
            }
            
        }
        else
        {
            echo '<script>alert("User Already exists")</script>';
        }
        
        
    }
    else
            {
                echo '<script>alert("Passwords Mismatch")</script>';
            }
   
    
   }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <h1 class=" text-center my-4">New User Registration</h1>
        <form action="" method="post" enctype="multipart/form-data">
                             <!--------User Name------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="user_name" class="form-label">User Name</label>
                <input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter User Name" required>
        </div>
                              <!--------User Email------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="user_email" class="form-label">Email</label>
                <input type="text" name="user_email" id="user_email" class="form-control" placeholder="Enter Valid Email ID" required>
        </div>
                            <!--------User Password------->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_password" class="form-label">Password</label>
             <input type="password" name="user_password" id="user_password" class="form-control" placeholder="Enter Password" required>
        </div>
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_cpassword" class="form-label">Confirm Password</label>
             <input type="password" name="user_cpassword" id="user_cpassword" class="form-control" placeholder="Enter Confirm Password" required>
        </div>
                           <!--------------Address------>
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_password" class="form-label">Address</label>
             <input type="text" name="user_address" id="user_address" class="form-control" placeholder="Enter Address" required>
        </div>
                            <!-------------Mobile Number---->
        <div class="form-outline mb-4 w-50 m-auto my-4">
             <label for="user_phone" class="form-label">Mobile Number</label>
             <input type="text" name="user_phone" id="user_phone" class="form-control" placeholder="Enter Phone Number" required>
        </div>

        <div class="form-outline mb-4 w-50 m-auto my-4">
             <button type="submit" class="bg-success p-2 my-3 border-0 text-white" name="register">Register</button>
             <p>Already have an account? <a href="userLogin.php">Login</a></p>
        </div>
        

        </form>
    </div>
</body>
</html>