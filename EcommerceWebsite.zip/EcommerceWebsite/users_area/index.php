<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce Site</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/responsiveness.css">
    <?php
        include('header.php');
    ?>

</head>
<body data-bs-spy="scroll">
       <!----------------Navigation Bar----------------->
       
    <!----------------Home Page---------------------->
    <section id="home" class="home pt-5 overflow-hidden">
        <div class="container text-center">
            
        </div>
        <div id="carouselExampleCaptions" class="carousel slide">
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          </div>
          <div class="carousel-inner">
            <div class="carousel-item active">
             <div class="home-banner home-banner-1">
              <div class="home-banner-text">
                <h1>Women</h1>
                <h2>50% Discount For the Season</h2>
                <a href="" class="btn btn-danger text-uppercase mt-4">Our Products</a>
              </div>
             </div>
            </div>
            <div class="carousel-item">
              <div class="home-banner home-banner-2">
                <div class="home-banner-text">
                  <h1>E-shop</h1>
                  <h2>With Working Card and PayPal</h2>
                  <a href="" class="btn btn-danger text-uppercase mt-4">Our Products</a>
                </div>
               </div>
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true">
              <span class="ti-angle-left slider-icon"></span>
            </span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true">
              <span class="ti-angle-right slider-icon"></span>
            </span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
       </section>    

       <!----------------Products----------------------->
       <section id="products" class="products">
            <!--------Products Images--------->
        <div class="container text-center">
          <h1>OUR PRODUCTS</h1>
            <p>Communication is at the heart of e-commerce and community</p>
            <!------First Card Row------------->

                  <!---------Dairy Products--------->
          <div class="row g-3">
                     <!-------Fetching Products from the database--->
            <?php
                  include('../databases/connection.php');
                  $select_query="select * from `products`";
                  $result_query=mysqli_query($conn,$select_query);
                  while($row=mysqli_fetch_assoc($result_query))
                  {
                    $product_id=$row['product_id'];
                    $product_title=$row['product_title'];
                    $product_descp=$row['product_description'];
                    $product_keywords=$row['product_keywords'];
                    $product_category=$row['product_category'];
                    $product_brand=$row['product_brand'];
                    $product_image=$row['product_image'];
                    $product_price=$row['price'];
                    echo "<div class='col-12 col-md-6 col-lg-4'>
                          <div class='card'>
                         <img src='../admin_area/product_images/$product_image' class='img-fluid card-img-top'>
                         <div class='card-body text-center'>
                         <h4 class='card-title'>$product_title</h4>
                         <p>$product_descp</p>
                         <p>RS:  $product_price</p>
                         <form action='add_to_cart.php' method='post'>
                          <input type='hidden' name='product_id' value='$product_id'>
                          <input type='hidden' name='product_title' value='$product_title'>
                          <input type='hidden' name='product_price' value='$product_price' '>
                          <input type='number' name='product_quantity' value='product_quantity' required='required placeholder='Enter Quantity'>
                          <button type='submit' name='add_to_cart' class='btn btn-danger'>Add To Cart</button>
                          </form>
                          </div>
                          </div>
                          </div>";
                  }
              ?>  
            </div>
          </div>

        </div>    
       </section>
       <!-----------------Special Section--------------->
       <section class="special" id="special">
        <div class="container text-center position-relative py-2 d-flex">
          <div class="row">
              <h1>SUMMER SALE</h1>
          <div class="col-sm-12 col-lg-7 text-center text-lg-start py-4">
            <div class="countdown-container">
              <h2 class="text-uppercase">Women Floral Embroidery</h2>
              <p class="my-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium labore harum dicta velit atque voluptatibus voluptatem ex similique? Molestiae voluptatum ex, eius culpa officia soluta hic dolore quae perspiciatis adipisci.</p>
              <ul class="list-unstyled countdown-counter">
                <li><span class="fs-1 d-block" id="days">00</span>Days</li>
                <li><span class="fs-1 d-block" id="hours">00</span>Hr</li>
                <li><span class="fs-1 d-block" id="min">00</span>Min</li>
                <li><span class="fs-1 d-block" id="sec">00</span>Sec</li>
              </ul>
            </div>
          </div>
          <div class="col-sm-12 col-lg-5">
            <div class="special-img position-relative">
              <img src="images/offer4.jpg" class="img-fluid">
              <span class="countdown-price p d-block mb-4" style="height: 0px;">$420.00 <del>$670.00</del></span>
              <button type="button" class="btn btn-danger" >Add to Cart</button>
            </div>
          </div>
        </div>
        </div>
       </section>

       <!----------------Testimonials------------------->
       <section class="testimonials" id="testimonials">
        <div class="container text-center">
          <div class="row">
            <div class="col-sm-12">
               <h1>Testimonials</h1>
            </div>
            <div class="col-sm-12 col-lg-8 offset-lg-2">
                <!----------Slider Pics--------->
                <div id="carouselExampleIndicatorsTwo" class="carousel slide" data-bs-ride="carousel">
                  <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleIndicatorsTwos" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicatorsTwo" data-bs-slide-to="1" aria-label="Slide 2"></button>
                  </div>
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                     <div class="testimonial-wrapper">
                      <div class="row">
                        <div class="col-sm-12">
                          <img src="images/user.png" class="img-fluid">
                        </div>
                        <div class="username">
                          <h3>Simona Saeed, Co-Founder CEO</h3>
                          <span>Fast Company Ltd</span>
                          <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Autem amet iusto soluta quisquam exercitationem, consequuntur consequatur aperiam suscipit voluptate recusandae voluptas sit illo aliquid sed nisi officiis deserunt culpa cum?</p>
                        </div>
                      </div>
                     </div>
                    </div>
                    <div class="carousel-item">
                      <div class="testimonial-wrapper">
                        <div class="row">
                          <div class="col-sm-12">
                            <img src="images/user2.png" class="img-fluid">
                          </div>
                          <div class="username">
                            <h3>Haris BUTT, HR Manager</h3>
                            <span>Fast Company Ltd</span>
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Autem amet iusto soluta quisquam exercitationem, consequuntur consequatur aperiam suscipit voluptate recusandae voluptas sit illo aliquid sed nisi officiis deserunt culpa cum?</p>
                          </div>
                        </div>
                       </div>
                    </div>
                  </div>
                  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicatorsTwo" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true">
                      <span class="ti-angle-left slider-icon"></span>
                    </span>
                    <span class="visually-hidden">Previous</span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicatorsTwo" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true">
                      <span class="ti-angle-right slider-icon"></span>
                    </span>
                    <span class="visually-hidden">Next</span>
                  </button>
                </div>
            </div>
          </div>
        </div>
       </section>
      <!-------------------Contact Section--------------->
      <section id="contact">
        <div class="contact">
          <div class="container">
            <h1 class="text-center">Contact Us</h1>
            <div class="contact-info py-4 m-4">
              <h3>Contact Info</h3>
              <p>+91 999 999 9456</p>
              <p>Info@eshop.in</p>
            </div>
          </div>
        </div>
      </section>
      <!-----------------Footer Section---------------->
      <footer>
        <div class="container text-white bg-danger">
          <div class="row align-items-center">
            <div class="col-12 col-lg-6 p-1 p-lg-3 text-center text-lg-start">
              <p class="my-0">CopyRight @ 2023 <a href="#">E-Shop</a>  All Rights Reserved</p>
            </div>
            <div class="col-12 col-lg-6 p-1 p-lg-3 text-center text-lg-end">
              <p>Designed by <a href="#" target="_blank">CODE4Education</a>.</p>
            </div>
          </div>
        </div>
      </footer>
       <script src="../js/script.js"></script>
</body>
</html>