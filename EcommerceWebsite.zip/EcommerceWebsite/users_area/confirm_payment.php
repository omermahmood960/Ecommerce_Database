<?php
    include('../databases/connection.php');
    session_start();
    $user_id=$_SESSION['id'];
    //select the transaction ID from transaction table
    $transaction_data="select * from transaction where user_id='$user_id'";
    $result_transaction=mysqli_query($conn,$transaction_data);
    $rows_transaction=mysqli_fetch_assoc($result_transaction);
    $Total_Bill=$_SESSION['bill'];
    $transaction_id=$rows_transaction['transaction_id'];
    
    
    
     
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class=" text-info">
        <div class="container my-5">
            <h1>Confirm Payment</h1>
            <form action="successfulPayment.php" method="post" enctype="multipart/form-data">
                <div class="form-outline my-4 text-center w-50 m-auto">
                <label for="" class="text-success">Transaction_ID</label>
                    <input type="text" class="form-control" name="transaction_id" value="<?php echo $transaction_id ?>" required>
                </div>
                <div class="form-outline my-4 text-center w-50 m-auto">
                    <label for="" class="text-success">Amount</label>
                    <input type="text" class="form-control" name="total_bill" value="<?php echo $Total_Bill ?>" required>
                </div>
                <div class="form-outline my-4 text-center w-50 m-auto">
                    <select name="payment_mode" id="" class="form-select w-50 m-auto" required>
                        <option value="">Select Payment Mode</option>
                        <option value="Jazzcash">Jazzcash</option>
                        <option value="EasyPaisa">EasyPaisa</option>
                        <option value="Cash On delivery">Cash on Delivery</option>
                    </select>
                </div>
                <div class="form-outline my-4 text-center w-50 m-auto">
                    <button type="submit" name="confirm_pay">Buy Now</button>
                </div>

            </form>
        </div>
    </div>
</body>
</html>
