<?php
include('bootstrap_classes.php');
session_start();
echo '<div class="alert alert-danger" role="alert">
      Logged out
      </div>';
echo  '<script>window.location.href="../index.php"</script>';

session_destroy();



?>