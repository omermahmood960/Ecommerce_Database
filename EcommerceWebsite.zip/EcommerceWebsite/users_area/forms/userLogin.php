<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <?php
        include('bootstrap_classes.php');
    ?>
</head>
<body>
        <?php 
           session_start();
           //Check whether User Logged in or not
           if(isset($_SESSION['user']))
           {
            header('location:../index.php');
           }
           else
           {
            echo '<div class="container-fluid">
            <h1 class=" text-center my-4">Login Form</h1>
            <form action="login.php" name="loginForm" method="post" enctype="multipart/form-data" onsubmit="return validateform()">
                                  <!--------User Email------>
            <div class="form-outline mb-4 w-50 m-auto my-4">
                <label for="user_name" class="form-label">Name</label>
                <input type="text" name="user_name" id="user_name" class="form-control" placeholder="Enter Valid user_name" required>
                <p class="text-danger" id="valid_name"></p>
            </div>
                                <!--------User Password------->
            <div class="form-outline mb-4 w-50 m-auto my-4">
                 <label for="user_password" class="form-label">Password</label>
                 <input type="password" name="user_password" id="user_password" class="form-control" placeholder="Enter Password" required>
                 <p class="text-danger" id="valid_password"></p>
            </div>
    
            <div class="form-outline mb-4 w-50 m-auto my-4 ">
                 <button type="submit" class="bg-success p-3 my-3 border-0 text-white">Login</button>
            </div>
            </form>
            </div> ';
           }
        
        ?>     
<script src="login.js"></script>

</html>