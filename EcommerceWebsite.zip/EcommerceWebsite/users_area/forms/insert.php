<?php
        include('../../databases/connection.php');
        if(isset($_POST['register']))
        {
        //Fetching the data from registration form
        $user_name=$_POST['user_name'];
        $user_email=$_POST['user_email'];
        $user_pass=$_POST['user_password'];
        $user_conf_pass=$_POST['user_cpassword'];
        $user_address=$_POST['user_address'];
        $user_number=$_POST['user_phone'];
        if($user_pass===$user_conf_pass)
        {
            $hash_pass=password_hash($user_pass,PASSWORD_DEFAULT);
            //select query for unique users
            $select_query="select * from users_table where user_email='$user_email'";
            $result_query=mysqli_query($conn,$select_query);
            $number=mysqli_num_rows( $result_query);
            if($number==0)
            {
                //Insertion into the database
                $sql_query="insert into `users_table` (user_Name,user_email,user_password,user_address,user_mobileNo) Values('$user_name','$user_email','$hash_pass',' $user_address',' $user_number')";
                $result_query=mysqli_query($conn,$sql_query);
                
                if($result_query)
                {
                    echo '<div class="alert alert-primary" role="alert">
                           Registered Successfully
                          </div>';
                    echo "<script>
                        window.location.href='../index.php'
                        </script>";
                }
                
            }
            else
            {
                echo '<div class="alert alert-primary" role="alert">
                            User Already exists
                    </div>';
                echo "<script>
                        window.location.href='login.php'
                    </script>";
                
            }
            
            
        }
        else
                {
                    echo '<div class="alert alert-primary" role="alert">
                            Passwords Mismatch
                        </div>';
                }

        
        }
//---------------Insertion of users updated data into database---------//
        if(isset($_POST['update']))
        {
            session_start();
            $user_id=$_SESSION['id'];
            
            $user_name=$_POST['user_name'];
            $user_pass=$_POST['user_password'];
            $user_address=$_POST['user_address'];
            $user_number=$_POST['user_phone'];
            // echo $user_name.'<br>'.$user_address.'<br>'.$user_number;
            $hash_pass=password_hash($user_pass,PASSWORD_DEFAULT);
                //Update query
                $update_query="update `users_table` set user_Name='$user_name',`user_password`='$hash_pass',user_MobileNo='$user_number' where user_id='$user_id'";
                $result_query=mysqli_query($conn, $update_query);
                
                if($result_query)
                {
                    echo   '<div class="alert alert-primary" role="alert">
                            Updated Successfully
                            </div>';
                echo    "<script>
                            window.location.href='../index.php'
                        </script>";
                }
                else
                {
                    echo '<div class="alert alert-primary" role="alert">
                            Error Something
                        </div>';
                    echo "<script>
                            window.location.href='../edit_form.php'
                        </script>";
                }
                
        }

            //----------Logic for Cancel of Button-------------//
                if(isset($_POST['cancel']))
                    {
                        echo        "<script>
                                        window.location.href='../index.php'
                                    </script>";
                    }

?>