//---------Validation---------------//
      function validateform()
      {  
        var userName=document.loginForm.user_name.value;  
        var userPassword=document.loginForm.user_password.value;  
      
        if (userName=="" || userName.length<3)
        {  
            document.getElementById("valid_name").innerHTML="Must be at least 3 characters";
            return false;  
        }
        if(userPassword.length<4)
        { 
            document.getElementById("valid_password").innerHTML="Password must contain at least 4 characters or digits";
            return false;  
        }  
     }  

    
