<?php
     include('../../databases/connection.php');
     include('bootstrap_classes.php');
     $user_name=$_POST['user_name'];
     $user_pass=$_POST['user_password'];

     $select_query="select * from users_table where user_Name = '$user_name'";
     $result_query=mysqli_query($conn,$select_query);
     $number=mysqli_num_rows($result_query);
     $row_data=mysqli_fetch_assoc($result_query);
     session_start();

     if($number>0)
     {
         if(password_verify($user_pass,$row_data['user_password']))
         {
           $_SESSION['user']=$user_name;
           // Fetching the users Id
            $user_id=$row_data['user_id'];
            
            $_SESSION['id']=$user_id;
            
            echo  "<script>window.location.href='../index.php'</script>";
         }
         else
         {
          echo '<div class="alert alert-primary" role="alert">
                   Invalid Password
                  </div>';
         }
     }
     else
     {
      echo '<div class="alert alert-primary" role="alert">
                   Invalid Credentials
            </div>'; 
     }
?>